package com.example.yessir;

import android.media.MediaPlayer;
import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;

import android.view.View;


import android.widget.Button;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        //Creates the yessir and nosir button which plays the sound of the audio for each
        MediaPlayer yessirski;
        MediaPlayer nosir=MediaPlayer.create(this,R.raw.nosir);
        Button playnoSir=(Button) this.findViewById(R.id.nosir);

        yessirski= MediaPlayer.create(this, R.raw.yessir);
        Button playYessir=(Button) this.findViewById(R.id.yessir);

        //This plays the sound of the Yessir Button and shows the message
        playYessir.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                yessirski.start();
                Toast.makeText(getApplicationContext(),"YESSIRRRRRRRRRRRRRR",Toast.LENGTH_SHORT).show();
            }
        }) ;
        //This plays the sound of the Nosir Button and shows the message
        playnoSir.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                nosir.start();
                Toast.makeText(getApplicationContext(),"NOSIRRRRRRRRRRRRRRRRRRRRR",Toast.LENGTH_SHORT).show();
            }
        });
        }

    }





